#created by madan

set ::env(DESIGN_NAME) “systolic_array"
set ::env(DESIGN_DIR) “/home/madank/OpenROAD-flow-scripts/flow/designs/systolic_array"
